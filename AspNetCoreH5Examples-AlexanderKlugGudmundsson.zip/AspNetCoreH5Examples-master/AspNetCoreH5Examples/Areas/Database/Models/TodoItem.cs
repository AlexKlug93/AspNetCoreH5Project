﻿using System;
using System.Collections.Generic;

namespace AspNetCoreH5Examples.Areas.Database.Models
{
    public partial class TodoItem
    {
        public int Id { get; set; }
        public string Title { get; set; } = null!;
        public string Description { get; set; } = null!;
        public string User { get; set; }
    }
}
