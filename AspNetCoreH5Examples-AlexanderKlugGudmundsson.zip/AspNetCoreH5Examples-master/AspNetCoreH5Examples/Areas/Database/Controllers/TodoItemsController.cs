﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AspNetCoreH5Examples.Areas.Database.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using System.Security.Principal;
using System.Security.Claims;
using Microsoft.AspNetCore.Identity;

namespace AspNetCoreH5Examples.Areas.Database.Controllers
{
    [Area("Database")]
    [Route("[controller]/[action]")]
    [Authorize("RequireAuthenticatedUser")]
    public class TodoItemsController : Controller
    {
        private readonly TodoDBContext _context;
        private readonly IDataProtector _protector;
        private readonly UserManager<IdentityUser> _userManager;

        public TodoItemsController(TodoDBContext context, IDataProtectionProvider protector, UserManager<IdentityUser> userManager)
        {
            _userManager = userManager;
            _context = context;
            _protector =
                protector.CreateProtector("AspNetCoreH5Examples.HomeController.Selvvalgt");

        }

        // GET: Database/TodoItems
        public async Task<IActionResult> Index()
        {
            //Get id of logged in user to only get the records from that user.
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var items = _context.TodoItems.Where(x => x.User == userId).ToList();
            foreach (var item in items)
            {
                item.Title = _protector.Unprotect(item.Title);
                item.Description = _protector.Unprotect(item.Description);
            }


            return View(await Task.Run(() => items));
        }

        // GET: Database/TodoItems/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }


            var todoItem = await _context.TodoItems
                .FirstOrDefaultAsync(m => m.Id == id);
            todoItem.Title = _protector.Unprotect(todoItem.Title);
            todoItem.Description = _protector.Unprotect(todoItem.Description);
            if (todoItem == null)
            {
                return NotFound();
            }

            return View(todoItem);
        }

        // GET: Database/TodoItems/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Database/TodoItems/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,Description,User")] TodoItem todoItem)
        {
            if (ModelState.IsValid)
            {
                todoItem.Description = _protector.Protect(todoItem.Description);
                todoItem.Title = _protector.Protect(todoItem.Title);
                _context.Add(todoItem);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(todoItem);
        }

        // GET: Database/TodoItems/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var items = _context.TodoItems.ToList();
            foreach (var item in items)
            {
                item.Title = _protector.Unprotect(item.Title);
                item.Description = _protector.Unprotect(item.Description);
            }

            var todoItem = await _context.TodoItems.FindAsync(id);
            if (todoItem == null)
            {
                return NotFound();
            }
            return View(todoItem);
        }

        // POST: Database/TodoItems/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Description,User")] TodoItem todoItem)
        {
            if (id != todoItem.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    todoItem.Title = _protector.Protect(todoItem.Title);
                    todoItem.Description = _protector.Protect(todoItem.Description);
                    _context.Update(todoItem);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TodoItemExists(todoItem.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(todoItem);
        }

        // GET: Database/TodoItems/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var todoItem = await _context.TodoItems
                .FirstOrDefaultAsync(m => m.Id == id);

            todoItem.Title = _protector.Unprotect(todoItem.Title);
            todoItem.Description = _protector.Unprotect(todoItem.Description);
            if (todoItem == null)
            {
                return NotFound();
            }

            return View(todoItem);
        }

        // POST: Database/TodoItems/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var todoItem = await _context.TodoItems.FindAsync(id);
            _context.TodoItems.Remove(todoItem);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TodoItemExists(int id)
        {
            return _context.TodoItems.Any(e => e.Id == id);
        }
    }
}
